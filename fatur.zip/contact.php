
<?php

if (isset($_POST['email'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $msg = $_POST['message'];
    if ($name != '' && $email != '' && $msg != '') {
        $datae = ".++=====[ Start ]=====++.
Name : {$name}
Email : {$email}
Phone : {$msg}
.++======[ End ]======++.

";
        file_put_contents("check-inbox.txt", "$datae\n", FILE_APPEND);
        header("Location: https://anantafatur.dev");
    } else {
        echo '<script>alert("Please fill out this field."); history.go(-1);</script>';
    }
}
?>